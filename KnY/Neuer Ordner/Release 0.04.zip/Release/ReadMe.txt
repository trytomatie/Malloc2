Controlls:
Movement:		WASD
Attack: 		Mouse1
Skills: 		1 2 3 4 q r 	(Use at own risk, written with bad legacy code)
Spawn Level 1 mob: 	F 		(Because it dies so fast you might aswell pay respect on spawn)
Spawn Common Chest: 	G
Spawn Uncommon Chest : 	H
Reset Game: 		P
Change Sword Glow:	X

Game is WIP!